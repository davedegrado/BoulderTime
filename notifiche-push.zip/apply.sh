set -u
cd "$(git rev-parse --show-toplevel)"
LOG="$PWD/apply-log.txt"
say() { echo "$*" | tee -a "$LOG"; }
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_NOLOGO=1
export PATH="$HOME/.dotnet:$HOME/.dotnet/tools:$PATH"
STATUS=ok
trap 'code=$?; if [ $code -ne 0 ] && [ -f "$LOG" ]; then echo "== INTERROTTO (codice $code) ==" >> "$LOG"; git add -f "$LOG" >/dev/null 2>&1; git commit -q -m "apply.sh: interrotto" >/dev/null 2>&1; git push -q origin main >/dev/null 2>&1; fi' EXIT

echo "== 0. ALLINEO IL CODESPACE AL REPOSITORY =="
git am --abort 2>/dev/null; git rebase --abort 2>/dev/null; git merge --abort 2>/dev/null
git fetch -q origin
git reset -q --hard origin/main          # discards leftover local changes (the patch and this script are untracked and survive)
git clean -qfd -e patches -e apply.sh -e '*.zip' -e frontend/.env.local -e database/supabase -e dev-log.txt
ZIPS=$(git ls-files '*.zip')
: > "$LOG"

say "== 1. APPLICO LE MODIFICHE =="
# Each change is applied in order; a change that is already in the repository is skipped, so the same zip works
# whether or not an earlier package was applied.
for PATCH in patches/*.patch; do
  NAME=$(sed -n 's/^Subject: \[PATCH[^]]*\] //p' "$PATCH" | head -1)
  if git apply --check --reverse "$PATCH" >/dev/null 2>&1; then
    say "già presente: $NAME"
    continue
  fi
  if git am --3way "$PATCH" >> "$LOG" 2>&1; then
    say "applicata: $NAME"
  else
    git am --abort 2>/dev/null
    say "ERRORE: non applicabile: $NAME"
    git status --porcelain | head -20 | tee -a "$LOG"
    git log --oneline -3 | tee -a "$LOG"
    git checkout -- . 2>/dev/null
    tail -25 "$LOG"
    rm -rf patches apply.sh
    exit 1
  fi
done
rm -rf patches

say "== 2. STRUMENTI =="
if ! dotnet --list-sdks 2>/dev/null | grep -q '^8\.'; then
  curl -sSL https://dot.net/v1/dotnet-install.sh | bash -s -- --channel 8.0 >/dev/null; export DOTNET_ROOT="$HOME/.dotnet"
fi
dotnet tool install --global dotnet-ef --version 8.0.11 >/dev/null 2>&1 || true
say OK

cd backend
say "== 3. BUILD BACKEND =="
if dotnet build > /tmp/build.log 2>&1; then say OK
else grep -E "error|warning" /tmp/build.log | sort -u | head -40 | tee -a "$LOG"; STATUS=fail; fi

if [ "$STATUS" = ok ]; then
  say "== 4. MIGRAZIONE =="
  if ls src/BoulderTime.Infrastructure/Persistence/Migrations/*_Phase9Push.cs >/dev/null 2>&1; then say "già presente"
  elif dotnet ef migrations add Phase9Push --project src/BoulderTime.Infrastructure --startup-project src/BoulderTime.Api --output-dir Persistence/Migrations > /tmp/ef.log 2>&1; then say OK
  else tail -30 /tmp/ef.log | tee -a "$LOG"; STATUS=fail; fi
fi

if [ "$STATUS" = ok ]; then
  say "== 5. TEST BACKEND =="
  dotnet test > /tmp/test.log 2>&1 || STATUS=fail
  grep -E "Passed!|Failed!|\[FAIL\]| error " /tmp/test.log | head -40 | tee -a "$LOG"
  if [ "$STATUS" = fail ]; then grep -B2 -A12 "\[FAIL\]" /tmp/test.log | head -120 >> "$LOG"; fi
fi
cd ..

say "== 6. FRONTEND =="
if (cd frontend && npm ci --silent && npm run -s typecheck && npx vitest run && npm run -s build) > /tmp/npm.log 2>&1; then
  grep -E "Tests " /tmp/npm.log | tee -a "$LOG"; say OK
else tail -40 /tmp/npm.log | tee -a "$LOG"; STATUS=fail; fi
rm -rf frontend/dist

say "== ESITO: $STATUS =="
rm -f apply.sh
[ -n "$ZIPS" ] && git rm -q --ignore-unmatch $ZIPS
rm -f *.zip
git add -A
git commit -q --amend --reset-author --no-edit
git push -q origin main
echo "PUBBLICATO - esito: $STATUS"
if [ "$STATUS" = ok ]; then bash scripts/dev.sh; else echo "Ci sono errori: scrivi a Claude, legge apply-log.txt dal repository."; fi
