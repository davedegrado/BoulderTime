set -u
cd "$(git rev-parse --show-toplevel)"
LOG="$PWD/apply-log.txt"; : > "$LOG"
say() { echo "$*" | tee -a "$LOG"; }
export DOTNET_CLI_TELEMETRY_OPTOUT=1 DOTNET_NOLOGO=1
export PATH="$HOME/.dotnet:$HOME/.dotnet/tools:$PATH"
ZIPS=$(git ls-files '*.zip')
STATUS=ok

say "== 1. APPLICO LE MODIFICHE =="
if git am --3way change.patch >> "$LOG" 2>&1; then say OK
else git am --abort 2>/dev/null; say "ERRORE: patch non applicabile"; rm -f change.patch apply.sh; exit 1; fi
rm -f change.patch

say "== 2. STRUMENTI =="
if ! dotnet --list-sdks 2>/dev/null | grep -q '^8\.'; then
  curl -sSL https://dot.net/v1/dotnet-install.sh | bash -s -- --channel 8.0 >/dev/null; export DOTNET_ROOT="$HOME/.dotnet"
fi
dotnet tool install --global dotnet-ef --version 8.0.11 >/dev/null 2>&1 || true
say OK

cd backend
say "== 3. BUILD BACKEND =="
if dotnet build > /tmp/build.log 2>&1; then say OK
else grep -E "error|warning" /tmp/build.log | sort -u | head -40 | tee -a "$LOG"; STATUS=fail; fi

if [ "$STATUS" = ok ]; then
  say "== 4. MIGRAZIONE =="
  if ls src/BoulderTime.Infrastructure/Persistence/Migrations/*_Phase2Gyms.cs >/dev/null 2>&1; then say "già presente"
  elif dotnet ef migrations add Phase2Gyms --project src/BoulderTime.Infrastructure --startup-project src/BoulderTime.Api --output-dir Persistence/Migrations > /tmp/ef.log 2>&1; then say OK
  else tail -30 /tmp/ef.log | tee -a "$LOG"; STATUS=fail; fi
fi

if [ "$STATUS" = ok ]; then
  say "== 5. TEST BACKEND =="
  dotnet test > /tmp/test.log 2>&1 || STATUS=fail
  grep -E "Passed!|Failed!|\[FAIL\]| error " /tmp/test.log | head -40 | tee -a "$LOG"
  if [ "$STATUS" = fail ]; then grep -B2 -A12 "\[FAIL\]" /tmp/test.log | head -120 >> "$LOG"; fi
fi
cd ..

say "== 6. FRONTEND =="
if (cd frontend && npm ci --silent && npm run -s typecheck && npx vitest run && npm run -s build) > /tmp/npm.log 2>&1; then say OK
else tail -30 /tmp/npm.log | tee -a "$LOG"; STATUS=fail; fi
rm -rf frontend/dist

say "== ESITO: $STATUS =="
rm -f apply.sh
[ -n "$ZIPS" ] && git rm -q $ZIPS
git add -A
git commit -q --amend --reset-author --no-edit
git push -q origin main
echo "PUBBLICATO - esito: $STATUS"

if [ "$STATUS" = ok ]; then
  echo "Avvio l'app..."
  bash scripts/dev.sh
else
  echo "Ci sono errori: scrivi a Claude, legge apply-log.txt dal repository."
fi
