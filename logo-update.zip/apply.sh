set -u
cd "$(git rev-parse --show-toplevel)"
LOG="$PWD/apply-log.txt"; : > "$LOG"
say() { echo "$*" | tee -a "$LOG"; }
ZIPS=$(git ls-files '*.zip')

say "== APPLICO LE MODIFICHE =="
if git am --3way change.patch >> "$LOG" 2>&1; then
  git commit -q --amend --reset-author --no-edit
  say OK
else
  git am --abort 2>/dev/null
  say "ERRORE: patch non applicabile"; rm -f change.patch apply.sh
  exit 1
fi
rm -f change.patch

say "== FRONTEND =="
STATUS=ok
cd frontend
if npm ci --silent > /tmp/npm.log 2>&1 && npm run -s typecheck >> /tmp/npm.log 2>&1 && npx vitest run >> /tmp/npm.log 2>&1 && npm run -s build >> /tmp/npm.log 2>&1; then
  say OK
else
  tail -30 /tmp/npm.log | tee -a "$LOG"; STATUS=fail
fi
rm -rf dist
cd ..

say "== ESITO: $STATUS =="
rm -f apply.sh verify-log.txt
[ -n "$ZIPS" ] && git rm -q $ZIPS
git rm -q --cached verify-log.txt 2>/dev/null
git add -A
git commit -q --amend --no-edit
git push -q origin main
echo "FINITO - esito: $STATUS"
