#!/usr/bin/env bash
# Applies the changes in patches/, generates any database migration the model needs, builds, runs every test and
# publishes. Safe to re-run.
set -uo pipefail
cd "$(git rev-parse --show-toplevel)"
LOG="apply-log.txt"
say() { echo "$@" | tee -a "$LOG"; }
EF="--project src/BoulderTime.Infrastructure --startup-project src/BoulderTime.Api"

git fetch -q origin && git reset -q --hard origin/main
git clean -qfd -e patches -e apply.sh -e '*.zip' -e frontend/.env.local -e database/supabase -e dev-log.txt
: > "$LOG"
export PATH="$HOME/.dotnet:$HOME/.dotnet/tools:$PATH" DOTNET_ROOT="$HOME/.dotnet"
STATUS=ok
trap 'code=$?; if [ $code -ne 0 ] && [ -f "$LOG" ]; then echo "== INTERROTTO (codice $code) ==" >> "$LOG"; git add -f "$LOG" >/dev/null 2>&1; git commit -q -m "apply.sh: interrotto" >/dev/null 2>&1; git push -q origin main >/dev/null 2>&1; fi' EXIT

say "== 1. APPLICO LE MODIFICHE =="
for PATCH in patches/*.patch; do
  NAME=$(sed -n 's/^Subject: \[PATCH[^]]*\] //p' "$PATCH" | head -1)
  if git apply --check --reverse "$PATCH" >/dev/null 2>&1; then say "già presente: $NAME"; continue; fi
  if git am --3way "$PATCH" >> "$LOG" 2>&1; then
    say "applicata: $NAME"
  else
    git am --abort 2>/dev/null
    say "ERRORE: non applicabile: $NAME"
    git status --porcelain | head -20 | tee -a "$LOG"
    git checkout -- . 2>/dev/null
    rm -rf patches apply.sh
    exit 1
  fi
done
rm -rf patches

say "== 2. STRUMENTI =="
if ! dotnet --list-sdks 2>/dev/null | grep -q '^8\.'; then
  curl -sSL https://dot.net/v1/dotnet-install.sh | bash -s -- --channel 8.0 >> "$LOG" 2>&1
fi
dotnet tool install --global dotnet-ef >> "$LOG" 2>&1 || dotnet tool update --global dotnet-ef >> "$LOG" 2>&1
say "OK"

# Asked of EF rather than hard-coded per package, so a model change can never ship without its migration.
say "== 3. MIGRAZIONE =="
PENDING=$(cd backend && dotnet ef migrations has-pending-model-changes $EF 2>&1)
if echo "$PENDING" | grep -qi "no changes have been made"; then
  say "nessuna modifica al modello"
elif echo "$PENDING" | grep -qiE "error|not found|unrecognized"; then
  say "NON VERIFICABILE:"; echo "$PENDING" | tail -5 | tee -a "$LOG"; STATUS=fail
else
  MIGRATION="Model$(date +%Y%m%d%H%M)"
  if (cd backend && dotnet ef migrations add "$MIGRATION" $EF --output-dir Persistence/Migrations >> "../$LOG" 2>&1); then
    say "creata: $MIGRATION"
  else
    say "FALLITA"; tail -15 "$LOG"; STATUS=fail
  fi
fi

say "== 4. BUILD BACKEND =="
if [ "$STATUS" = ok ]; then
  if (cd backend && dotnet build -v q >> "../$LOG" 2>&1); then say "OK"; else say "FALLITO"; STATUS=fail; fi
fi

say "== 5. TEST BACKEND =="
if [ "$STATUS" = ok ]; then
  (cd backend && dotnet test -v q --logger "console;verbosity=detailed" > ../test-output.txt 2>&1) || STATUS=fail
  if [ "$STATUS" = fail ]; then
    grep -E "\[FAIL\]|Error Message|Assert|Expected|Actual|Exception" test-output.txt | head -40 | tee -a "$LOG"
  fi
  grep -E "Passed!|Failed!" test-output.txt | tail -1 | tee -a "$LOG"
  rm -f test-output.txt
fi

say "== 6. FRONTEND =="
if (cd frontend && npm ci --silent >> "../$LOG" 2>&1 && npx tsc -b --noEmit >> "../$LOG" 2>&1 \
    && npx vitest run > ../vitest-output.txt 2>&1; rc=$?; grep -E "Tests |×|→" ../vitest-output.txt | head -20 | tee -a "../$LOG"; rm -f ../vitest-output.txt; [ $rc -eq 0 ] \
    && npm run -s build >> "../$LOG" 2>&1); then say "OK"; else say "FALLITO"; STATUS=fail; fi

say "== ESITO: $STATUS =="
rm -rf frontend/node_modules frontend/dist frontend/android/app/src/main/assets/public apply.sh test-output.txt vitest-output.txt *.zip
git add -A && git commit -q -m "apply.sh: $(date +%F\ %H:%M) ($STATUS)" && git push -q origin main && say "Pubblicato."
