set -u
cd "$(git rev-parse --show-toplevel)"
ZIPS=$(git ls-files '*.zip')
echo "== Applico le modifiche =="
if ! git am --3way change.patch; then
  git am --abort 2>/dev/null; rm -f change.patch apply.sh
  echo "ERRORE: patch non applicabile"; exit 1
fi
rm -f change.patch apply.sh
[ -n "$ZIPS" ] && git rm -q $ZIPS
git commit -q --amend --reset-author --no-edit
git push -q origin main && echo "Pubblicato."
# Only the dev script changed: no rebuild or tests needed. Start the app.
bash scripts/dev.sh
